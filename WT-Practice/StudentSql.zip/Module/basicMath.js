
function sum(x, y) {
    return x + y;
}

function sub(x, y) {
    return x - y;
}

function product(x, y) {
    return x * y;
}

function div(x, y) {
    return x / y;
}

module.exports = {
    add: sum,
    sub: sub,
    multiplication: product,
    div: div
};