
const math = require('./basicMath.js');

console.log("Addition (5 + 3):", math.add(5, 3));
console.log("Subtraction (5 - 3):", math.sub(5, 3));
console.log("Multiplication (5 * 3):", math.multiplication(5, 3));
console.log("Division (5 / 3):", math.div(5, 3));