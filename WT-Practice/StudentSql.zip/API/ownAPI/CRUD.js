const express = require('express');
const app = express();
app.use(express.json());

let books = [];

// Add a new book
app.post('/books', (req, res) => {
    const { title, author, isbn, year } = req.body;
    if (!title || !author || !isbn || !year) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    const existing = books.find(book => book.isbn === isbn);
    if (existing) {
        return res.status(409).json({ message: 'Book with this ISBN already exists' });
    }
    books.push({ title, author, isbn, year });
    res.status(201).json({ message: 'Book added' });
});

// Get all books
app.get('/books', (req, res) => {
    res.json(books);
});

// Get book by ISBN
app.get('/books/:isbn', (req, res) => {
    const book = books.find(b => b.isbn === req.params.isbn);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.json(book);
});

// Update book by ISBN
app.put('/books/:isbn', (req, res) => {
    const index = books.findIndex(b => b.isbn === req.params.isbn);
    if (index === -1) return res.status(404).json({ message: 'Book not found' });

    const { title, author, year } = req.body;
    if (!title || !author || !year) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    books[index] = { isbn: req.params.isbn, title, author, year };
    res.json({ message: 'Book updated' });
});

// Delete book by ISBN
app.delete('/books/:isbn', (req, res) => {
    const index = books.findIndex(b => b.isbn === req.params.isbn);
    if (index === -1) return res.status(404).json({ message: 'Book not found' });

    books.splice(index, 1);
    res.json({ message: 'Book deleted' });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
